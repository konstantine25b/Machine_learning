#!/bin/bash
# Script to combine PDF files for CS231n Assignment 2 submission
set -euo pipefail

# Define PDF files in the order they should appear
PDF_FILES=(
    "FullyConnectedNets.pdf"
    "BatchNormalization.pdf"
    "Dropout.pdf"
    "ConvolutionalNetworks.pdf"
    "PyTorch.pdf"
)

OUTPUT_FILE="a2_inline_submission.pdf"

C_R="\e[31m"
C_G="\e[32m"
C_BLD="\e[1m"
C_E="\e[0m"

# Check that all required files exist
for FILE in "${PDF_FILES[@]}"
do
    if [ ! -f ${FILE} ]; then
        echo -e "${C_R}Required file ${FILE} not found, Exiting.${C_E}"
        exit 1
    fi
done

echo -e "${C_BLD}### Combining PDFs into ${OUTPUT_FILE} ###${C_E}"

# Check if we have pdfunite (from poppler utils)
if command -v pdfunite &> /dev/null; then
    pdfunite "${PDF_FILES[@]}" "${OUTPUT_FILE}"
    echo -e "${C_G}Successfully created ${OUTPUT_FILE} using pdfunite${C_E}"
# Check if we have pdftk
elif command -v pdftk &> /dev/null; then
    pdftk "${PDF_FILES[@]}" cat output "${OUTPUT_FILE}"
    echo -e "${C_G}Successfully created ${OUTPUT_FILE} using pdftk${C_E}"
# Fallback to Python if available
elif command -v python3 &> /dev/null || command -v python &> /dev/null; then
    # Create a temp Python script
    TEMP_SCRIPT=$(mktemp)
    cat > "${TEMP_SCRIPT}" << 'EOF'
from PyPDF2 import PdfMerger
import sys

def merge_pdfs(output_path, input_paths):
    merger = PdfMerger()
    for path in input_paths:
        merger.append(path)
    merger.write(output_path)
    merger.close()
    print(f"Successfully created {output_path}")

if __name__ == "__main__":
    output_file = sys.argv[1]
    input_files = sys.argv[2:]
    merge_pdfs(output_file, input_files)
EOF

    # Try with python3 first, then python if needed
    if command -v python3 &> /dev/null; then
        echo "Using Python3 to combine PDFs..."
        python3 -m pip install PyPDF2 --quiet || echo "Failed to install PyPDF2. Continuing anyway in case it's already installed."
        python3 "${TEMP_SCRIPT}" "${OUTPUT_FILE}" "${PDF_FILES[@]}" && \
        echo -e "${C_G}Successfully created ${OUTPUT_FILE} using Python${C_E}"
    else
        echo "Using Python to combine PDFs..."
        python -m pip install PyPDF2 --quiet || echo "Failed to install PyPDF2. Continuing anyway in case it's already installed."
        python "${TEMP_SCRIPT}" "${OUTPUT_FILE}" "${PDF_FILES[@]}" && \
        echo -e "${C_G}Successfully created ${OUTPUT_FILE} using Python${C_E}"
    fi
    
    # Clean up the temp script
    rm "${TEMP_SCRIPT}"
else
    echo -e "${C_R}Could not find any PDF merging tools. Please install pdfunite (poppler-utils), pdftk, or Python with PyPDF2.${C_E}"
    exit 1
fi

echo -e "${C_BLD}### Done! Please submit ${OUTPUT_FILE} to Gradescope. ###${C_E}" 